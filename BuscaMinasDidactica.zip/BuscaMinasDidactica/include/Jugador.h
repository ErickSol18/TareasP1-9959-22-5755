#ifndef JUGADOR_H
#define JUGADOR_H


class Jugador
{
    public:
        Jugador();

        void vidasRestantes();


    protected:

    private:
};

#endif // JUGADOR_H
